<?php
/*
Plugin Name: WP Query Analyzer Lite
Description: Real-time WordPress query analyzer with duplicate highlighting, toggle panel, JSON export, and duration filter in microseconds.
Version: 1.4
Author: Your Name
*/

if (!defined('ABSPATH')) {
    exit;
}

add_action('wp_footer', 'wqa_render_query_panel');

function wqa_render_query_panel() {
    if (!current_user_can('manage_options')) return;
    if (!defined('SAVEQUERIES') || !SAVEQUERIES) return;
    if (!isset($GLOBALS['wpdb']->queries) || empty($GLOBALS['wpdb']->queries)) return;

    $queries = $GLOBALS['wpdb']->queries;
    $duplicates = [];

    foreach ($queries as $query_data) {
        list($query, $duration) = $query_data;
        $hash = md5($query);
        if (isset($duplicates[$hash])) {
            $duplicates[$hash]['count']++;
        } else {
            $duplicates[$hash] = ['count' => 1, 'query' => $query];
        }
    }
    ?>
    <div id="wqa-panel" style="
        position: fixed; 
        bottom: 10px; 
        right: 10px; 
        width: 90vw; 
        max-width: 700px; 
        max-height: 400px; 
        background: #f9f9f9; 
        color: #222; 
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
        border: 1px solid #ccc; 
        border-radius: 8px; 
        box-shadow: 0 4px 10px rgb(0 0 0 / 0.1);
        display: flex; 
        flex-direction: column;
        overflow: hidden;
        z-index: 999999;
    ">
        <div id="wqa-header" style="
            background: #fff; 
            border-bottom: 1px solid #ddd; 
            padding: 10px 15px; 
            display: flex; 
            justify-content: space-between; 
            align-items: center;
            position: sticky;
            top: 0;
            z-index: 10;
            box-shadow: 0 2px 4px rgb(0 0 0 / 0.05);
        ">
            <h3 style="margin: 0; font-weight: 600; font-size: 1rem; color: #333;">🧠 WP Query Analyzer</h3>
            <div style="display: flex; align-items: center; gap: 8px;">
                <button id="wqa-toggle-btn" style="
                    background: transparent; 
                    border: 1px solid #777; 
                    color: #555; 
                    padding: 5px 12px; 
                    font-size: 0.9rem; 
                    border-radius: 4px; 
                    cursor: pointer;
                    transition: background-color 0.3s, color 0.3s;
                " onmouseover="this.style.backgroundColor='#eee'; this.style.color='#222';" onmouseout="this.style.backgroundColor='transparent'; this.style.color='#555';">Hide</button>
                <button id="wqa-export-btn" style="
                    background: transparent; 
                    border: 1px solid #777; 
                    color: #555; 
                    padding: 5px 12px; 
                    font-size: 0.9rem; 
                    border-radius: 4px; 
                    cursor: pointer;
                    transition: background-color 0.3s, color 0.3s;
                " onmouseover="this.style.backgroundColor='#eee'; this.style.color='#222';" onmouseout="this.style.backgroundColor='transparent'; this.style.color='#555';">Export JSON</button>
                <label for="wqa-min-duration" style="font-size: 0.9rem; color: #444; margin-left: 10px;">Min μs:</label>
                <input id="wqa-min-duration" type="number" min="0" step="1" value="0" style="
                    width: 70px; 
                    padding: 4px 8px; 
                    border: 1px solid #ccc; 
                    border-radius: 4px; 
                    font-size: 0.9rem;
                " title="Show queries slower than this threshold in microseconds">
            </div>
        </div>
        <div id="wqa-content" style="overflow-y: auto; padding: 15px; flex-grow: 1; font-size: 0.85rem;">
        <?php 
        $total_time = 0;
        foreach ($queries as $query_data) {
            list($query, $duration) = $query_data;
            $total_time += $duration;
            $hash = md5($query);
            $is_duplicate = (isset($duplicates[$hash]) && $duplicates[$hash]['count'] > 1);
            ?>
            <div class="wqa-query" data-duration-us="<?php echo esc_attr($duration * 1000000); ?>" style="margin-bottom: 8px; background: <?php echo $is_duplicate ? '#f0f5f1' : 'transparent'; ?>; <?php echo $is_duplicate ? 'border-left: 4px solid #d69e2e; padding-left: 11px;' : ''; ?> border-bottom: 1px solid #ddd; padding-bottom: 6px; font-weight: 500; color: #222;">
                <strong style="color: <?php echo $duration > 0.00005 ? '#c53030' : '#2f855a'; ?>; min-width: 70px; display: inline-block;"><?php echo number_format($duration, 5); ?>s</strong> - <span><?php echo esc_html($query); ?></span>
                <?php if ($is_duplicate) echo '<span style="color: #d69e2e; font-weight:bold;"> &nbsp; (Duplicate × '.$duplicates[$hash]['count'].')</span>'; ?>
            </div>
        <?php } ?>
        <p style="color:#666; font-weight:bold; margin-top: 10px; border-top: 1px solid #eee; padding-top: 8px;">
            Total queries: <?php echo count($queries); ?> | Total time: <?php echo number_format($total_time, 5); ?>s
        </p>
        </div>
    </div>

    <script>
    (function(){
        const panel = document.getElementById('wqa-panel');
        const content = document.getElementById('wqa-content');
        const toggleBtn = document.getElementById('wqa-toggle-btn');
        const exportBtn = document.getElementById('wqa-export-btn');
        const minDurationInput = document.getElementById('wqa-min-duration');

        toggleBtn.addEventListener('click', () => {
            if(content.style.display !== 'none') {
                content.style.display = 'none';
                toggleBtn.textContent = 'Show';
                panel.style.height = '50px';
                panel.style.overflow = 'visible';
            } else {
                content.style.display = 'block';
                toggleBtn.textContent = 'Hide';
                panel.style.height = 'auto';
                panel.style.overflow = 'hidden';
            }
        });

        exportBtn.addEventListener('click', () => {
            const queries = <?php echo json_encode($queries, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;
            const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(queries, null, 2));
            const dlAnchor = document.createElement('a');
            dlAnchor.setAttribute("href", dataStr);
            dlAnchor.setAttribute("download", "wp-query-analyzer-" + new Date().toISOString().slice(0,10) + ".json");
            document.body.appendChild(dlAnchor);
            dlAnchor.click();
            dlAnchor.remove();
        });

        function filterQueries() {
            const threshold = parseFloat(minDurationInput.value) || 0;
            const queries = document.querySelectorAll('.wqa-query');
            queries.forEach(q => {
                const durationUs = parseFloat(q.getAttribute('data-duration-us'));
                if (durationUs >= threshold) {
                    q.style.display = 'block';
                } else {
                    q.style.display = 'none';
                }
            });
        }

        minDurationInput.addEventListener('input', filterQueries);

        filterQueries();
    })();
    </script>
    <?php
}
